package org.spring.ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McpServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
